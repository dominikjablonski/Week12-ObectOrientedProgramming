import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * For this program we used serialization and we synthesized the presenter's program from the YouTube video.
 * We then had to add our own touches for the rest of the requirements so that we could meet all of them. 
 */

class Person implements Serializable {
	String name;
	
	public Person(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Person [Name = " + name + "]";
	}
}
class PhoneNum implements Serializable {
	String phoneNum;
	
	public PhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	
	@Override
	public String toString() {
		return "Phone Number [Number = " + phoneNum + "]";
	}
}
class DOB implements Serializable {
	String dob;
	
	public DOB(String dob) {
		this.dob = dob;
	}
	
	@Override
	public String toString() {
		return "Date of Brith [Date = " + dob + "]";
	}
}
class Email implements Serializable {
	String email;
	
	public Email(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "Email Address [Email = " + email + "]";
	}
}
public class Test {
	static String choice;
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		Scanner userInput = new Scanner(System.in);
		
		boolean program = true;
		while (program) {
			program = askMenu();
		}
	}
	
	public static boolean  askMenu() throws FileNotFoundException, IOException {
		Scanner userInput = new Scanner(System.in);
		System.out.println("What would you like to do? \n 1) Add Jimmy's information to the File \n 2) Retrieve and Display Information \n 3) Delete Information \n"
				+ " 4) Update Information \n 5) Exit ");
		choice = userInput.nextLine();
		menu();
		
		return false;
	}
	
	public static void menu() throws FileNotFoundException, IOException {
		Scanner userInput = new Scanner(System.in);
		switch(choice)
		{
			case "1":
				Person jimmy = new Person("Jimmy Neutron");
				PhoneNum num = new PhoneNum("630-656-8229");
				DOB birth = new DOB("4/24/1998");
				Email emailAddress = new Email("jablodominik@gmail.com");
				
				try {
					writeToFile(jimmy, num, birth, emailAddress);
				} catch (IOException e) {
					System.out.println(e.getMessage());
				}
				cont();
				break;
			case "2":
				try {
					readFile();
				} catch (ClassNotFoundException | IOException e) {
					System.out.println(e.getMessage());
				} 
				cont();
				break;
			case "3":
				new FileOutputStream("Person.bin").close();
				cont();
				break;
			case "4":
				new FileOutputStream("Person.bin").close();
				System.out.println("Who would you like to choose? \n 1) Lizzie \n 2) John \n 3) Mike \n 4) Kelly");
				choice = userInput.nextLine();
				switch(choice) {
				case "1":
					Person lizzie = new Person("Lizzie McGuire");
					PhoneNum num2 = new PhoneNum("630-445-7689");
					DOB birth2 = new DOB("6/04/1998");
					Email emailAddress2 = new Email("LizzieMcGuire@gmail.com");
					try {
						writeToFile(lizzie, num2, birth2, emailAddress2);
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				case "2":
					Person john = new Person("John Rahm");
					PhoneNum num3 = new PhoneNum("630-323-4432");
					DOB birth3 = new DOB("11/09/1991");
					Email emailAddress3 = new Email("JohnRahm@gmail.com");
					try {
						writeToFile(john, num3, birth3, emailAddress3);
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				case "3":
					Person mike = new Person("Mike Kelly");
					PhoneNum num4 = new PhoneNum("630-221-9990");
					DOB birth4 = new DOB("11/23/1991");
					Email emailAddress4 = new Email("MikeKelly@gmail.com");
					try {
						writeToFile(mike, num4, birth4, emailAddress4);
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				case "4":
					Person kelly = new Person("Kelly Fitz");
					PhoneNum num5 = new PhoneNum("630-001-2389");
					DOB birth5 = new DOB("7/09/1991");
					Email emailAddress5 = new Email("MikeKelly@gmail.com");
					try {
						writeToFile(kelly, num5, birth5, emailAddress5);
					} catch (IOException e) {
						System.out.println(e.getMessage());
					}
				
				}
				cont();
			case "5":
				break;
		}
	}
	public static void cont() throws FileNotFoundException, IOException {
		Scanner userInput = new Scanner(System.in);
		String end2;
		System.out.println("1) Continue Menu \n2) Finish");
		end2 = userInput.nextLine();
		switch(end2) 
		{
			case "1":
				askMenu();
				break;
			case "2":
				break;
		}
	}
	
	public static void writeToFile (Person p, PhoneNum n, DOB d, Email a) throws IOException {
		ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("Person.bin"));
		
		output.writeObject(p);
		output.writeObject(n);
		output.writeObject(d);
		output.writeObject(a);
	}
	
	public static void readFile() throws IOException, ClassNotFoundException {
		ObjectInputStream input = new ObjectInputStream(new FileInputStream("Person.bin"));
		
		Person name = (Person) input.readObject();
		PhoneNum phoneNum = (PhoneNum) input.readObject();
		DOB dob = (DOB) input.readObject();
		Email email = (Email) input.readObject();
		System.out.println(name);
		System.out.println(phoneNum);
		System.out.println(dob);
		System.out.println(email);
	}
}
